package com.Shippa.shippa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseAuthUserCollisionException;

public class SignUp extends AppCompatActivity {


    private FirebaseAuth mAuth;
    ProgressBar pr;

    EditText EmailEdt, PasswordEdt;
    Button RegistrationButton;

    TextView logintxt;


    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_sign_up);



        mAuth = FirebaseAuth.getInstance();

        pr = findViewById(R.id.pr);
        EmailEdt = findViewById(R.id.Email_EdittextSn);
        PasswordEdt = findViewById(R.id.Password_EdittextSn);

        RegistrationButton = findViewById(R.id.SignUp_Button);
        logintxt = findViewById(R.id.SignUpTxt);

        pr.setVisibility(View.GONE);

        logintxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                /// Different way to move to another activity
                startActivity(new Intent(getApplicationContext(), MainActivity.class));
                finish();
            }
        });

        RegistrationButton.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                RegisterUser();
                pr.setVisibility(View.VISIBLE);
            }
        });
    }


    public void RegisterUser(){

        String email = EmailEdt.getText().toString().trim();
        String password = PasswordEdt.getText().toString().trim();

        if (email.isEmpty()){

            EmailEdt.setError("Email is required!");
            EmailEdt.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){

            EmailEdt.setError("Please enter a valid Email.");
            EmailEdt.requestFocus();
            return;
        }

        if (password.isEmpty()){

            PasswordEdt.setError("Password is required!");
            PasswordEdt.requestFocus();

            return;
        }

        if(password.length() > 6){

            PasswordEdt.setError("Password minimum length is 6");
            PasswordEdt.requestFocus();

            return;

        }


        mAuth.createUserWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {
                pr.setVisibility(View.GONE);

                if(task.isSuccessful()){

                    Toast.makeText(getApplicationContext(), "You have successfully been registered.", Toast.LENGTH_SHORT).show();

                    Intent toProfile = new Intent(getApplicationContext(), Profile.class);
                    toProfile.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(toProfile);

                }else{

                    if(task.getException() instanceof FirebaseAuthUserCollisionException){ // if the email has already been taken

                        Toast.makeText(getApplicationContext(), "This email has already been registered.", Toast.LENGTH_SHORT).show();

                    }else {

                        Toast.makeText(getApplicationContext(), task.getException().getMessage(), Toast.LENGTH_SHORT).show();

                    }


                }
            }
        });


    }

}
