package com.Shippa.shippa;

import androidx.annotation.NonNull;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.os.Bundle;
import android.util.Patterns;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.AuthResult;
import com.google.firebase.auth.FirebaseAuth;

public class MainActivity extends AppCompatActivity {

    private FirebaseAuth mAuth;
    ProgressBar pr;

    TextView SignUpTxt;
    Button Login;

    EditText EmailEdt, PasswordEdt;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_main);
        mAuth = FirebaseAuth.getInstance();
        pr = findViewById(R.id.pr);
        pr.setVisibility(View.INVISIBLE);

        SignUpTxt = findViewById(R.id.LogInTxt);
        Login = findViewById(R.id.LogIn_Button);

        EmailEdt = findViewById(R.id.Email_Edittext);
        PasswordEdt = findViewById(R.id.Password_Edittext);

        SignUpTxt.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                finish();
                Intent SignUpIntent = new Intent(getApplicationContext(), SignUp.class);
                startActivity(SignUpIntent);

            }
        });

        Login.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                UserLogin();

            }
        });

    }


    public void UserLogin(){

        String email = EmailEdt.getText().toString().trim();
        String password = PasswordEdt.getText().toString().trim();

        if (email.isEmpty()){

            EmailEdt.setError("Email is required!");
            EmailEdt.requestFocus();
            return;
        }

        if(!Patterns.EMAIL_ADDRESS.matcher(email).matches()){

            EmailEdt.setError("Please enter a valid Email.");
            EmailEdt.requestFocus();
            return;
        }

        if (password.isEmpty()){

            PasswordEdt.setError("Password is required!");
            PasswordEdt.requestFocus();

            return;
        }

        if(password.length() > 6){

            PasswordEdt.setError("Password minimum length is 6");
            PasswordEdt.requestFocus();

            return;

        }


        pr.setVisibility(View.VISIBLE);

        // The difference between sign in and login methods is the "signInWithEmailAndPasswordMethod and the CreateUserWithEmailAndPassword"

        mAuth.signInWithEmailAndPassword(email, password).addOnCompleteListener(new OnCompleteListener<AuthResult>() {
            @Override
            public void onComplete(@NonNull Task<AuthResult> task) {

                if(task.isSuccessful()){

                    finish();
                    Intent toProfile = new Intent(getApplicationContext(), Profile.class);
                    toProfile.addFlags(Intent.FLAG_ACTIVITY_CLEAR_TOP);
                    startActivity(toProfile);



                }else{

                    Toast.makeText(MainActivity.this, task.getException().getMessage(), Toast.LENGTH_SHORT).show();
                    EmailEdt.setError("Re check your email!");

                    PasswordEdt.setError("Re check your Password!");
                    PasswordEdt.requestFocus();

                    pr.setVisibility(View.INVISIBLE);

                }

            }
        });


    }

    @Override
    protected void onStart() {
        super.onStart();

        /// This is how you check if the user is logged in

        if(mAuth.getCurrentUser() != null){

            Intent toProfile = new Intent(getApplicationContext(), Profile.class);
            startActivity(toProfile);

            finish();


        }

    }
}
