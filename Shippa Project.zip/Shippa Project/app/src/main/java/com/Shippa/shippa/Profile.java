package com.Shippa.shippa;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.appcompat.app.AppCompatActivity;

import android.content.Intent;
import android.graphics.Bitmap;
import android.net.Uri;
import android.net.http.SslError;
import android.os.Bundle;
import android.provider.MediaStore;
import android.view.View;
import android.webkit.SslErrorHandler;
import android.webkit.WebView;
import android.webkit.WebViewClient;
import android.widget.Button;
import android.widget.EditText;
import android.widget.ImageView;
import android.widget.ProgressBar;
import android.widget.TextView;
import android.widget.Toast;

import com.bumptech.glide.Glide;
import com.google.android.gms.tasks.OnCompleteListener;
import com.google.android.gms.tasks.OnFailureListener;
import com.google.android.gms.tasks.OnSuccessListener;
import com.google.android.gms.tasks.Task;
import com.google.firebase.auth.FirebaseAuth;
import com.google.firebase.auth.FirebaseUser;
import com.google.firebase.auth.UserProfileChangeRequest;
import com.google.firebase.storage.FirebaseStorage;
import com.google.firebase.storage.StorageReference;
import com.google.firebase.storage.UploadTask;

import org.w3c.dom.Text;

import java.io.IOException;

public class Profile extends AppCompatActivity {


    FirebaseAuth mAuth;
    FirebaseUser user;

    private static final int CHOOSE_IMAGE = 101;

    ImageView ImageChooser;
    ProgressBar pr;

    TextView Save;

    EditText DisplayName;

    Uri uriProfileImage;

    String profielImageUrl;

    TextView textView, SignOut, QuickPay;

    WebView webView;

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        setContentView(R.layout.activity_profile);
        mAuth = FirebaseAuth.getInstance();

        ImageChooser = findViewById(R.id.ImageChooser);
        Save = findViewById(R.id.Save_btn);
        DisplayName = findViewById(R.id.UserName_EdditText);
        pr = findViewById(R.id.pr);
        pr.setVisibility(View.INVISIBLE);

        textView = findViewById(R.id.Verify);
        SignOut = findViewById(R.id.SignOut_Text);

        QuickPay = findViewById(R.id.QuickPay);

        webView = findViewById(R.id.webview);

        webView.setWebViewClient(new WebViewClient(){
            @Override
            public void onReceivedSslError(WebView view, SslErrorHandler handler, SslError error) {
                handler.proceed();
            }
        });

        openURL();

        loadUserInformation();

        QuickPay.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                Intent Payment = new Intent(getApplicationContext(), PayMentPart.class);
                startActivity(Payment);

            }
        });

        ImageChooser.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                showImageChooser();

            }
        });

        Save.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                saveUserInformation();

            }
        });


        SignOut.setOnClickListener(new View.OnClickListener() {
            @Override
            public void onClick(View v) {

                FirebaseAuth.getInstance().signOut();
                startActivity(new Intent(getApplicationContext(), MainActivity.class));

            }
        });



    }

    public void loadUserInformation(){

        user = mAuth.getCurrentUser();


        if(user != null) {
            if (user.getPhotoUrl() != null) {

                Glide.with(this)
                        .load(user.getPhotoUrl().toString()
                        ).into(ImageChooser /*This also serves as an imageView*/); // the getPhotoUrl is a built in method

            }

            if (user.getDisplayName() != null) {

                DisplayName.setText(user.getDisplayName()); // The display Name Edittext
            }

            if(user.isEmailVerified()){

                textView.setText("Email Verified");

            }else{

                textView.setText("Email not Verified(Click Here to veryfiy)");

                textView.setOnClickListener(new View.OnClickListener() {
                    @Override
                    public void onClick(View v) {
                        user.sendEmailVerification().addOnCompleteListener(new OnCompleteListener<Void>() {
                            @Override
                            public void onComplete(@NonNull Task<Void> task) {
                                Toast.makeText(Profile.this, "Verification Email sent", Toast.LENGTH_SHORT).show();
                            }
                        });
                    }
                });

            }

        }

    }

    private void saveUserInformation() {

        String displayName = DisplayName.getText().toString();

        if(displayName.isEmpty()){

            DisplayName.setError("Enter name!");
            DisplayName.requestFocus();
            return;

        }

        FirebaseUser user = mAuth.getCurrentUser();

        if(user != null && profielImageUrl != null){

            UserProfileChangeRequest profile = new UserProfileChangeRequest.Builder()
                    .setDisplayName(displayName)
                    .setPhotoUri(Uri.parse(profielImageUrl))
                    .build();

            user.updateProfile(profile)
                    .addOnCompleteListener(new OnCompleteListener<Void>() {
                        @Override
                        public void onComplete(@NonNull Task<Void> task) {

                            Toast.makeText(Profile.this, "Profile Updated", Toast.LENGTH_SHORT).show();

                        }
                    });


        }


    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, @Nullable Intent data) {
        super.onActivityResult(requestCode, resultCode, data);


        if(requestCode == CHOOSE_IMAGE && resultCode == RESULT_OK && data != null && data.getData() != null){

            uriProfileImage = data.getData(); // When you tap an Image you get this Data returned

            try {

                Bitmap bitmap = MediaStore.Images.Media.getBitmap(getContentResolver(), uriProfileImage);
                ImageChooser.setImageBitmap(bitmap);

                uploadImageToFirebaseStorage();

            } catch (IOException e) {
                e.printStackTrace();
            }

        }

    }

    private void uploadImageToFirebaseStorage() {

        final StorageReference profileImageRef =
                FirebaseStorage.getInstance().getReference("profilepics/" + System.currentTimeMillis() + ".jpg");

        if(uriProfileImage != null){

            pr.setVisibility(View.VISIBLE);

            profileImageRef.putFile(uriProfileImage).addOnSuccessListener(new OnSuccessListener<UploadTask.TaskSnapshot>() {
                @Override
                public void onSuccess(UploadTask.TaskSnapshot taskSnapshot) {

                    /// After the file has been put
                    pr.setVisibility(View.GONE);

                    taskSnapshot.getMetadata().getReference().getDownloadUrl().addOnCompleteListener(new OnCompleteListener<Uri>() {
                        @Override
                        public void onComplete(@NonNull Task<Uri> task) {

                            profielImageUrl = task.getResult().toString();
                           /* deal.setImageUtl(url);
                            deal.setImageName(taskSnapshot.getStorage().getPath());
                            showImage(url);
                            progressBar.setVisibility(View.INVISIBLE);*/
                        }
                    });

                }



            }).addOnFailureListener(new OnFailureListener() {
                @Override
                public void onFailure(@NonNull Exception e) {

                    Toast.makeText(Profile.this, e.getMessage(), Toast.LENGTH_SHORT).show();

                }
            });

        }

    }

    private void showImageChooser(){

        Intent intent = new Intent();
        intent.setType("image/*");
        intent.setAction(Intent.ACTION_GET_CONTENT);
        startActivityForResult(Intent.createChooser(intent, "Select Profile Image"), CHOOSE_IMAGE);

    }

    @Override
    protected void onStart() {
        super.onStart();

        /// This is how you check if the user is logged in

        if(mAuth.getCurrentUser() == null){

            Intent toProfile = new Intent(getApplicationContext(), MainActivity.class);
            startActivity(toProfile);

            finish();


        }

    }

    private void openURL() {
        webView.loadUrl("https://noormosia.github.io/tadhack/");
        webView.requestFocus();
    }

}
